/////////////////////////////////////////////////////////////
///shooting game using python3
///
///Created by KIM, HYUNWOO - YONSEI EE
////////////////////////////////////////////////////////////

/******GAME CONTROLE**********/
arrow key - movement of the airplane
space bar - shoot
ESC - terminate game


/***********GAME RULE*********/

get score if you defeat monster
higher score if you destroy strong monster


/***********HOW TO PLAY*********/


$ unzip shooting_py3.zip
$ cd shooting
$ python3 shoot.py





